﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senbazuruproject
{
    class EdgePotentialFeatureVector
    {
        public IList<int> features = new List<int>();
        
        public bool HasEdge = false;

        public EdgePotentialFeatureVector(IList<int> features)
        {
            this.features = features ;
        }
    }
}
