﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senbazuruproject
{
    class Program
    {
        static String Filename ;
        static void Main(string[] args)
        {
            Filename = @"D:\Work Space\Senbazuruproject\SenbazuruTestCopy.xlsx";
            ExcelReaderInterop reader = new ExcelReaderInterop();
            reader.OpenExcel(Filename);
        }
    }
}
