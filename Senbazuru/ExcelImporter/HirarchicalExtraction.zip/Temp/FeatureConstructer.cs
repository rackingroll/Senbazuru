﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Senbazuruproject
{
    class FeatureConstructer
    {
        public IList<AnotationPair> anotationPairList;
        public IList<AnotationPairEdge> anotationPairEdgeList;

        private Worksheet sheet = null ;
        private IList<Range> celllist;

        public FeatureConstructer(Worksheet sheet, Range AttributeRange)
        {
            this.AnotationPairConstruction(AttributeRange, sheet);
            this.AnotationPairEdgeConstruction();
            this.NodeFeatureVectorConstruction();
            this.EdgeFeatureVectorConstruction();
            this.sheet = sheet;
        }

        private void AnotationPairConstruction(Range AttributeRange, Worksheet sheet, bool SampleConstruction = true)
        {

            this.anotationPairList = new List<AnotationPair>();
            this.celllist = new List<Range>();

            int rowcount = AttributeRange.Rows.Count;
            int colnum = AttributeRange.Column ;

            for (int i = 1; i< rowcount ; i++ )
            {
                celllist.Add(AttributeRange.Cells[i, colnum]);
            }

            // Exhaust Construction
            if (SampleConstruction)
            {
                for (int i = 0; i < celllist.Count; i++)
                {
                    for (int j = 0; j < celllist.Count; j++)
                    {
                        if (i != j)
                        {
                            AnotationPair pair = new AnotationPair(celllist, i, j);
                            anotationPairList.Add(pair);
                        }

                    }
                }
            }
        }

        private void AnotationPairEdgeConstruction(bool SampleConstruction = true)
        {

            anotationPairEdgeList = new List<AnotationPairEdge>();

            // Exhaust Construction
            if (SampleConstruction)
            {
                for (int i = 0; i < anotationPairList.Count; i++)
                {
                    for (int j = i+1; j < anotationPairList.Count; j++)
                    {
                        if (i != j)
                        {
                            AnotationPairEdge PairEdge = new AnotationPairEdge(anotationPairList[i],anotationPairList[j]) ;
                            anotationPairEdgeList.Add(PairEdge);
                        }

                    }
                }
            }
        }

        private void NodeFeatureVectorConstruction()
        {
            ModelFeatures Features = new ModelFeatures();

            for (int i = 0; i < anotationPairList.Count; i++)
            {

                List<int> featureVector = new List<int>();
                featureVector.Add(Features.BFeatureAdjacent(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureBlankCellMiddle(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureChildindentationGreater(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureChildindexGreater(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureChildSizeSmaller(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureContainColonAndTotal(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureIndentationLarger(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureIndentationMiddle(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureIndentationShorter(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureParentRoot(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureStyleAdjacent(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));
                featureVector.Add(Features.BFeatureStyleDiffer(this.celllist, anotationPairList[i].indexParent, anotationPairList[i].indexParent));

                NodePotentialFeatureVector nodepotentialfeaturevector = new NodePotentialFeatureVector(featureVector);
                anotationPairList[i].nodepotentialfeaturevector = nodepotentialfeaturevector;
            }
        }

        private void EdgeFeatureVectorConstruction()
        {
            ModelFeatures Features = new ModelFeatures();

            for (int i = 0; i < anotationPairEdgeList.Count; i++)
            {
                List<int> featureVector = new List<int>();
                featureVector.Add(Features.EFeatureStylisticAffinity(this.celllist, anotationPairEdgeList[i].pair1.indexParent, anotationPairEdgeList[i].pair1.indexChild, anotationPairEdgeList[i].pair2.indexParent, anotationPairEdgeList[i].pair2.indexChild));
                featureVector.Add(Features.EFeatureMetaDataAffinity(this.celllist, anotationPairEdgeList[i].pair1.indexParent, anotationPairEdgeList[i].pair1.indexChild, anotationPairEdgeList[i].pair2.indexParent, anotationPairEdgeList[i].pair2.indexChild));
                featureVector.Add(Features.EFeatureAdjacentDependency(this.celllist, anotationPairEdgeList[i].pair1.indexParent, anotationPairEdgeList[i].pair1.indexChild, anotationPairEdgeList[i].pair2.indexParent, anotationPairEdgeList[i].pair2.indexChild));
                EdgePotentialFeatureVector edgepotentialfeaturevector = new EdgePotentialFeatureVector(featureVector);
                anotationPairEdgeList[i].edgepotentialfeaturevector = edgepotentialfeaturevector;
            }
        }
    }
}
